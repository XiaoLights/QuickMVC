﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Speaking.Dic
{
    public class Pages
    {
        private static List<VM_Page> d = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        static Pages()
        {
            d = new List<VM_Page>();
            d.Add(new VM_Page { Controller = "Home", Action = "Index", Name = "用户管理", NavTopId = 1, NavLeftId = 1 });

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="controller"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        public static VM_Page Get(string controller, string action)
        {
            return d.Where(w => w.Controller == controller && w.Action == action).FirstOrDefault();
        }
    }

    public class VM_Page
    {
        public string Controller { get; set; }
        public string Action { get; set; }
        public string Name { get; set; }
        public int? NavTopId { get; set; }
        public int? NavLeftId { get; set; }
    }
}
