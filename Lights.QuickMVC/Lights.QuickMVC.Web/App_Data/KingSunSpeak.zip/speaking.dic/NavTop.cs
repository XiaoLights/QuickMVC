﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Speaking.Dic
{
    public class NavTop
    {
        private static List<VM_NavTop> d = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        static NavTop()
        {
            d = new List<VM_NavTop>();
            d.Add(new VM_NavTop { Id = 1, Name = "首页", Url = "/Home/Index", Icon = "glyphicon glyphicon-home", Sort = 10, IsEnabled = true });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static List<VM_NavTop> Get()
        {
            return d.Where(w => w.IsEnabled == true).OrderBy(o => o.Sort).ToList();
        }
    }

    public class VM_NavTop
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
        public string Icon { get; set; }
        public int? Sort { get; set; }
        public bool IsEnabled { get; set; }
    }
}
