﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Speaking.Dic
{
    public class NavLeft
    {
        private static List<VM_NavLeft> d = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        static NavLeft()
        {
            d = new List<VM_NavLeft>();
            d.Add(new VM_NavLeft { Id = 1, NavTopId = 1, Name = "用户管理", Url = "/Home/Index", Icon = "", Sort = 1 });

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public static List<VM_NavLeft> Get(int? NavTopId)
        {
            return d.Where(w => w.NavTopId == NavTopId).ToList();
        }
    }


    public class VM_NavLeft
    {
        public int Id { get; set; }
        public int NavTopId { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
        public string Icon { get; set; }
        public int? Sort { get; set; }
    }
}
