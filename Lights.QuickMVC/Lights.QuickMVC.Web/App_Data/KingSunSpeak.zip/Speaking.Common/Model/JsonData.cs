﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Speaking.Common.Model
{
    public enum JsonDataFlag
    {
        /// <summary>
        /// 成功
        /// </summary>
        Succeed = 1,
        /// <summary>
        /// 验证失败
        /// </summary>
        ValidFailed = 0,
        /// <summary>
        /// 系统异常
        /// </summary>
        Exception = -1,
        /// <summary>
        /// 没有权限
        /// </summary>
        NoPermission = -2,
        /// <summary>
        /// 登录超时
        /// </summary>
        OverTime = -3,
    }
    public class JsonData
    {
        /// <summary>
        /// 返回结果类型：1-成功，2-验证失败，3-系统异常，4-没有权限，5-登录超时(或者没有登录)
        /// </summary>
        public JsonDataFlag flag { get; set; }

        /// <summary>
        /// 返回结果消息
        /// </summary>
        public string msg { get; set; }

        /// <summary>
        /// 返回结果数据
        /// </summary>
        public object data { get; set; }
    }

    /// <summary>
    /// 服务处理结果输出
    /// </summary>
    public class KingResponse
    {
        /// <summary>
        /// 操作是否成功
        /// </summary>
        public bool Success
        {
            get;
            set;
        }

        /// <summary>
        /// 业务数据
        /// </summary>
        public object Data
        {
            get;
            set;
        }

        public int ErrorCode { get; set; }

        /// <summary>
        /// 错误信息
        /// </summary>
        public string ErrorMsg
        {
            get;
            set;
        }

        /// <summary>
        /// 按错误数据创建输出对象
        /// </summary>
        /// <param name="errorMsg"></param>
        /// <returns></returns>
        public static KingResponse GetErrorResponse(string errorMsg)
        {
            KingResponse response = new KingResponse();
            response.Success = false;
            response.ErrorMsg = errorMsg;
            response.Data = null;
            return response;
        }

        public static KingResponse GetErrorResponse(int errorCode, string errorMsg)
        {
            KingResponse response = new KingResponse();
            response.Success = false;
            response.ErrorMsg = errorMsg;
            response.ErrorCode = errorCode;
            response.Data = null;
            return response;
        }

        public static KingResponse GetResponse(object data)
        {
            KingResponse res = new KingResponse();
            res.Success = true;
            res.Data = data;
            return res;
        }


        public static KingResponse RESGetResponse(object data)
        {
            KingResponse response = new KingResponse();
            response.Success = true;
            response.ErrorMsg = "";
            response.Data = data;
            return response;
        }
    }


}
