﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Speaking.Common
{
    public static class AppSetting
    {

        private static string _IISVirtualName;

        public static string IISVirtualName
        {
            get
            {
                if (string.IsNullOrEmpty(_IISVirtualName))
                {
                    _IISVirtualName = System.Configuration.ConfigurationManager.AppSettings["IISVirtualName"] as string;
                }
                return _IISVirtualName;
            }


        }
    }
}
