﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Speaking.Common
{
    public class Function
    {
        /// <summary>
        /// 给一个字符串进行MD5加密
        /// </summary>
        /// <param name="strText">待加密字符串</param>
        /// <returns>加密后的字符串</returns>
        public static string MD5Encrypt(string strText)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] result = md5.ComputeHash(System.Text.Encoding.Default.GetBytes(strText));
            return System.Text.Encoding.Default.GetString(result);
        }
    }


    /// <summary>
    /// DES加密操作 
    /// </summary>
    public static class DESEncrypt
    {
        private const string _iv = "RFV%$BGT";
        private const string _key = "Z9ZUO";

        static TripleDESCryptoServiceProvider _des = new TripleDESCryptoServiceProvider();
        private static Encoding _encoding = Encoding.UTF8;

        /// <summary>
        /// 
        /// </summary>
        /// <value>The encoding mode.</value>
        public static Encoding EncodingMode
        {
            get
            {
                return _encoding;
            }
            set
            {
                _encoding = value;
            }
        }

        /// <summary>
        /// DES加密，
        /// </summary>
        /// <param name="str">The STR.</param>
        /// <returns>返回加密字符串</returns>
        public static string Encrypt(string str, string encryptyKey)
        {
            encryptyKey = encryptyKey.Replace("-", "");
            if (encryptyKey.Length < 19)
            {
                encryptyKey = encryptyKey.PadRight(19, '0');
            }
            string iv = _iv;
            string key = _key + encryptyKey.Substring(0, 19);
            if (String.IsNullOrEmpty(key))
                return null;
            var ivb = Encoding.ASCII.GetBytes(iv);
            var keyb = Encoding.ASCII.GetBytes(key);
            var tob = EncodingMode.GetBytes(str);
            byte[] encrypted;

            try
            {
                // Create a MemoryStream.
                MemoryStream mStream = new MemoryStream();

                TripleDESCryptoServiceProvider tdsp = new TripleDESCryptoServiceProvider();
                tdsp.Mode = CipherMode.CBC;             //默认值
                tdsp.Padding = PaddingMode.PKCS7;       //默认值

                // Create a CryptoStream using the MemoryStream 
                // and the passed key and initialization vector (IV).
                CryptoStream cStream = new CryptoStream(mStream,
                    _des.CreateEncryptor(keyb, ivb),
                    CryptoStreamMode.Write);

                // Write the byte array to the crypto stream and flush it.
                cStream.Write(tob, 0, tob.Length);
                cStream.FlushFinalBlock();

                // Get an array of bytes from the 
                // MemoryStream that holds the 
                // encrypted data.
                encrypted = mStream.ToArray();

                // Close the streams.
                cStream.Close();
                mStream.Close();

                return Convert.ToBase64String(encrypted);
                // Return the encrypted buffer.
                //return EncodingMode.GetString(encrypted);
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return string.Empty;
            }
        }


        /// <summary>
        /// Des解密
        /// </summary>
        /// <param name="inputStr">密文串</param>
        /// <param name="encryptyKey"></param>
        /// <returns>解密后的字符串</returns>
        public static string Decrypt(string inputStr, string encryptyKey)
        {
            char[] charBuffer = inputStr.ToCharArray();
            byte[] tob = Convert.FromBase64CharArray(charBuffer, 0, charBuffer.Length);
            //byte[] tob = EncodingMode.GetBytes(inputStr);
            encryptyKey = encryptyKey.Replace("-", "");
            if (encryptyKey.Length < 19)
            {
                encryptyKey = encryptyKey.PadRight(19, '0');
            }
            string iv = _iv;
            string key = _key + encryptyKey.Substring(0, 19);

            if (String.IsNullOrEmpty(key))
                return null;

            var ivb = Encoding.ASCII.GetBytes(iv);
            var keyb = Encoding.ASCII.GetBytes(key);
            // var tob = EncodingMode.GetBytes(str);
            byte[] encrypted;
            try
            {
                // Create a new MemoryStream using the passed 
                // array of encrypted data.
                if (tob == null)
                    return null;
                MemoryStream msDecrypt = new MemoryStream();

                TripleDESCryptoServiceProvider tdsp = new TripleDESCryptoServiceProvider();
                tdsp.Mode = CipherMode.CBC;
                tdsp.Padding = PaddingMode.PKCS7;

                // Create a CryptoStream using the MemoryStream 
                // and the passed key and initialization vector (IV).
                CryptoStream csDecrypt = new CryptoStream(msDecrypt,
                    tdsp.CreateDecryptor(keyb, ivb),
                    CryptoStreamMode.Read);

                ///////////
                ICryptoTransform desdecrypt123 = tdsp.CreateDecryptor(keyb, ivb);
                MemoryStream writerS123 = new MemoryStream();
                CryptoStream cryptostreamDecr123 = new CryptoStream(writerS123, desdecrypt123, CryptoStreamMode.Write);
                cryptostreamDecr123.Write(tob, 0, tob.Length);
                cryptostreamDecr123.FlushFinalBlock();
                encrypted = writerS123.ToArray();
                /////////////

                //// Create buffer to hold the decrypted data.
                //encrypted = new byte[msDecrypt.Length];

                //// Read the decrypted data out of the crypto stream
                //// and place it into the temporary buffer.
                //csDecrypt.Read(encrypted, 0, encrypted.Length);
                //// csDecrypt.FlushFinalBlock();

                ////Convert the buffer into a string and return it.
                return EncodingMode.GetString(encrypted);
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return null;
            }
        }
    }
}
