﻿using Speaking.Common.Model;
using Speaking.DataBase;
using Speaking.Web.ApiModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Speaking.Web.Controllers
{
    [AllowAnonymous]
    public class InterfaceController : Controller
    {
        // GET: Interface
        public ActionResult Index()
        {
            InitCookie();
            return View();
        }

        public ActionResult Dazhi()
        {
            InitCookie();
            return View();
        }

        private void InitCookie()
        {
            string param = Request.Form["username"];
            string token = Request.Form["token"];

            HttpCookie cookie = Request.Cookies.Get("client");
            HttpCookie cookietoken = Request.Cookies.Get("token");
            if (string.IsNullOrEmpty(param))
            {
                if (cookie != null && !string.IsNullOrEmpty(cookie.Value))
                {
                    param = Common.DESEncrypt.Decrypt(cookie.Value, "Kingsunsoft");
                }
                else
                {
                    param = null;
                }
            }
            if (string.IsNullOrEmpty(token))
            {
                if (cookietoken != null && !string.IsNullOrEmpty(cookietoken.Value))
                {
                    token = Common.DESEncrypt.Decrypt(cookietoken.Value, "Kingsunsoft");
                }
                else
                {
                    token = null;
                }
            }
            if (cookie == null)
            {
                cookie = new HttpCookie("client");
            }
            if (cookietoken == null)
            {
                cookietoken = new HttpCookie("token");
            }
            if (CheckToken(token))
            {
                if (string.IsNullOrEmpty(param) || string.IsNullOrEmpty(token))
                {
                    cookie.Value = "";
                    cookie.Expires = DateTime.Now.AddMonths(-1);
                    Response.Cookies.Add(cookie);
                    cookietoken.Value = "";
                    cookietoken.Expires = DateTime.Now.AddMonths(-1);
                    Response.Cookies.Add(cookietoken);
                }
                else
                {
                    cookie.Value = Common.DESEncrypt.Encrypt(param, "Kingsunsoft");
                    cookie.Expires = DateTime.Now.AddMinutes(30);
                    Response.Cookies.Add(cookie);
                    cookietoken.Value = Common.DESEncrypt.Encrypt(token, "Kingsunsoft");
                    cookietoken.Expires = DateTime.Now.AddMinutes(30);
                    Response.Cookies.Add(cookietoken);
                }
            }
            else
            {
                cookie.Value = "";
                cookie.Expires = DateTime.Now.AddMonths(-1);
                Response.Cookies.Add(cookie);
                cookietoken.Value = "";
                cookietoken.Expires = DateTime.Now.AddMonths(-1);
                Response.Cookies.Add(cookietoken);
            }

        }

        private bool CheckToken(string token)
        {
            if (token == null || string.IsNullOrEmpty(token.Trim()))
            {
                return false;
            }
            using (var db = new KingSunSpeakingEntities())
            {
                var tokeninfo = db.tb_token.Where(i => i.token == token).FirstOrDefault();
                if (tokeninfo != null)
                {
                    return true;
                }
                return false;
            }
        }

        public JsonResult GoToClass()
        {
            HttpCookie cookie = Request.Cookies.Get("client");
            if (cookie == null)
            {
                return Json(KingResponse.GetErrorResponse("请登录！"));
            }
            try
            {
                string username = cookie.Value;
                //string username = "13689535120";
                username = Common.DESEncrypt.Decrypt(username, "Kingsunsoft");
                using (var db = new KingSunSpeakingEntities())
                {
                    var userinfo = db.TB_UserInfo.Where(i => i.UserName == username).FirstOrDefault();
                    if (userinfo == null)
                    {
                        return Json(KingResponse.GetErrorResponse("用户不存在！"));
                    }
                }
                JsonDatas jd = new ApiControllers.UserController().GetToken(new ApiModels.UserToken { username = username });
                string url = System.Configuration.ConfigurationManager.AppSettings.Get("LoginToUrl");
                string str = jd.data.Substring(jd.data.LastIndexOf("af_token:"));
                str = str.Replace("af_token:", "").Replace("}", "").Replace("]", "");
                url = url + str;
                return Json(KingResponse.GetResponse(url));
            }
            catch (Exception ex)
            {
                return Json(KingResponse.GetErrorResponse("跳转失败！" + ex.Message));
            }

        }

        public JsonResult GetClass()
        {
            HttpCookie cookie = Request.Cookies.Get("client");
            if (cookie == null)
            {
                return Json(KingResponse.GetErrorResponse("请登录！"));
            }
            try
            {
                string username = cookie.Value;
                // string username = "13689535120";
                username = Common.DESEncrypt.Decrypt(username, "Kingsunsoft");
                using (var db = new KingSunSpeakingEntities())
                {
                    var userinfo = db.TB_UserInfo.Where(i => i.UserName == username).FirstOrDefault();
                    if (userinfo == null)
                    {
                        return Json(KingResponse.GetErrorResponse("用户不存在！"));
                    }
                    JsonDatas jd = new ApiControllers.UserController().GetFreeCourse(new StuFreLog { studentPhone = userinfo.UserName });
                    if (jd.code == "1")
                    {
                        return Json(KingResponse.GetResponse(""));
                    }
                    else
                    {
                        return Json(KingResponse.GetErrorResponse(jd.message));
                    }
                }
            }
            catch (Exception ex)
            {
                return Json(KingResponse.GetErrorResponse("获取失败！" + ex.Message));
            }
        }
    }
}