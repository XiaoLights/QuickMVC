﻿using Speaking.DataBase;
using Speaking.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Speaking.Web.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index(VM_UserInfo_Index m)
        {
            if (m.Grid == null)
            {
                m.Grid = new Speaking.Common.Model.PList<VM_UserInfo_Index_Grid>();
                m.Grid.Pager = new Speaking.Common.Model.Pager();
            }
            using (var db = new KingSunSpeakingEntities())
            {
                var query = db.TB_UserInfo.OrderBy(o => o.CreateTime).AsQueryable();

                if (!string.IsNullOrWhiteSpace(m.Key))
                    query = query.Where(w => w.UserName.Contains(m.Key));

                if (!string.IsNullOrWhiteSpace(m.other) && m.other != "全部")
                    query = query.Where(w => w.Resource.Contains(m.other));

                m.Grid.Pager = new Speaking.Common.Model.Pager(m.Grid.Pager.PageIndex, m.Grid.Pager.PageSize, query.Count());
                m.Grid.Data = query.Skip((m.Grid.Pager.PageIndex - 1) * m.Grid.Pager.PageSize).Take(m.Grid.Pager.PageSize).Select(s => new VM_UserInfo_Index_Grid
                {
                    UserId = s.UserId,
                    Resource = s.Resource,
                    UserName = s.UserName,
                    RealName = s.RealName,
                    Phone = s.TelePhone,
                    CreateTime = s.CreateTime

                }).ToList();
            }
            return View(m);
        }
    }
}