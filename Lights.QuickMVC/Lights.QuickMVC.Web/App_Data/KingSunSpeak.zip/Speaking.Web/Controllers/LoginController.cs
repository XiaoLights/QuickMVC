﻿using Speaking.DataBase;
using Speaking.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Speaking.Web.Controllers
{
    [AllowAnonymous]
    public class LoginController : BaseController
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(VM_Login m)
        {
            if (ModelState.IsValid)
            {

                using (var db = new KingSunSpeakingEntities())
                {
                    var _m = db.sys_user.Where(_ => _.Account.Contains(m.Account)).FirstOrDefault();
                    if (_m == null)
                    {
                        ModelState.AddModelError("Account", "你输入的帐号不存在！");
                        return View(m);
                    }
                    else if (_m.Password != Speaking.Common.Function.MD5Encrypt(m.Password))
                    {
                        ModelState.AddModelError("Password", "密码错误！");
                        return View(m);
                    }
                    else
                    {
                        VM_SyPassport_UserInfo info = new VM_SyPassport_UserInfo();
                        info.Id = _m.UserId;
                        info.Name = _m.Name;
                        System.Web.HttpContext.Current.Session["UserInfo"] = info;
                        return RedirectToAction("Index", "Home");
                    }
                }
            }

            return View(m);
        }

        [HttpPost]
        public JsonResult Exit()
        {
            System.Web.HttpContext.Current.Session["UserInfo"] = null;
            return Json(new { flag = 1 });
        }
    }
}