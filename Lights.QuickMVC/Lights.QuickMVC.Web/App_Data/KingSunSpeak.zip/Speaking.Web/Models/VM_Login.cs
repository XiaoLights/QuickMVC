﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Speaking.Web.Models
{
    public class VM_Login
    {
        [Required]
        [MaxLength(25)]
        [Display(Name = "帐号")]
        public string Account { get; set; }

        [Required]
        [MaxLength(25)]
        [Display(Name = "密码")]
        public string Password { get; set; }
    }

    public class VM_SyPassport_UserInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}