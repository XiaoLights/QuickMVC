﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Speaking.Web.Models
{
    public class VM_UserInfo_Index
    {
        public string Key { get; set; }

        public string other { get; set; }
        public Speaking.Common.Model.PList<VM_UserInfo_Index_Grid> Grid { get; set; }
    }

    public class VM_UserInfo_Index_Grid
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Resource { get; set; }
        public DateTime? CreateTime { get; set; }

        public string Phone { get; set; }
        public string RealName { get; set; }

    }
}