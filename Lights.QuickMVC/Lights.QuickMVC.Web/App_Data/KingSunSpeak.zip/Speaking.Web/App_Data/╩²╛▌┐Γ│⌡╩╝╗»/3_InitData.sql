--����Ϊ123456
SET IDENTITY_INSERT [KingSunSpeaking].[dbo].[sys_user] ON
INSERT [KingSunSpeaking].[dbo].[sys_user] ([UserId], [Account], [Password], [Name], [State]) VALUES (1, N'admin', N'??I�Y��V�W??', N'����Ա', 0)
SET IDENTITY_INSERT [KingSunSpeaking].[dbo].[sys_user] OFF

INSERT INTO [KingSunSpeaking].[dbo].[tb_token]([token],[createdate] ,[expirdate],[remark]) VALUES('dazhi6ccc38a2','2017-08-21 19:20:45.753',null,'��֪ϵͳʹ�õ�token')
INSERT INTO [KingSunSpeaking].[dbo].[tb_token]([token],[createdate] ,[expirdate],[remark]) VALUES('niujin2228996e','2017-08-21 19:20:45.753',null,'ţ��ϵͳʹ�õ�token')
