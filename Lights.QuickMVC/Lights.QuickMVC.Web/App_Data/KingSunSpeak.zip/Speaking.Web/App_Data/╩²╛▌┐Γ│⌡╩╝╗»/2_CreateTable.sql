USE KingSunSpeaking

if exists (select 1
            from  sysobjects
           where  id = object_id('TB_UserInfo')
            and   type = 'U')
   drop table TB_UserInfo
go

/*==============================================================*/
/* Table: TB_UserInfo                                           */
/*==============================================================*/
create table TB_UserInfo (
   UserId               int                  identity,
   UserName             varchar(20)          null,
   Resource             varchar(50)          null,
   CreateTime           datetime             null,
   UserIdMod            varchar(50)          null,
   UserType             int                  null,
   Password             varchar(20)          null,
   RealName             varchar(20)          null,
   Sex                  varchar(10)          null,
   AddTime              datetime             null,
   "Identity"           varchar(20)          null,
   Grade                varchar(20)          null,
   Status               int                  null,
   YUid                 int                  null,
   constraint PK_TB_USERINFO primary key (UserId)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '���',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'UserId'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'UserName'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��Դ',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'Resource'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����ʱ��',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'CreateTime'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��ֱ���ݳر��',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'UserIdMod'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�û����ͣ�1����ʦ ��2��ѧ����',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'UserType'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '����',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'Password'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��ʵ����',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'RealName'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�Ա�',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'Sex'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��ʦ����ְ���� ѧ������ѧʱ��',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'AddTime'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '���ݣ�������Ϊ��ʦ��',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'Identity'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�꼶��������Ϊѧ����',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'Grade'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�û�״̬ 1������ 2���ܾ���¼',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'Status'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '������������id',
   'user', @CurrentUser, 'table', 'TB_UserInfo', 'column', 'YUid'
go



if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('sys_user_and_role') and o.name = 'FK_SYS_USER_AND_ROLE_REFERENCE_SYS_USER')
alter table sys_user_and_role
   drop constraint FK_SYS_USER_AND_ROLE_REFERENCE_SYS_USER
go

if exists (select 1
            from  sysobjects
           where  id = object_id('sys_user')
            and   type = 'U')
   drop table sys_user
go

/*==============================================================*/
/* Table: sys_user                                              */
/*==============================================================*/
create table sys_user (
   UserId               int                  identity,
   Account              varchar(50)          not null,
   Password             varchar(50)          not null,
   Name                 varchar(50)          not null,
   State                int                  not null,
   constraint PK_SYS_USER primary key (UserId)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '0-������1-ͣ�ã�2-ɾ��',
   'user', @CurrentUser, 'table', 'sys_user', 'column', 'State'
go


if exists (select 1
            from  sysobjects
           where  id = object_id('TB_GetRecord')
            and   type = 'U')
   drop table TB_GetRecord
go

/*==============================================================*/
/* Table: TB_GetRecord                                          */
/*==============================================================*/
create table TB_GetRecord (
   Id                   int                  identity,
   Phone                varchar(20)          null,
   CreateTime           datetime             null,
   constraint PK_TB_GETRECORD primary key (Id)
)
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '���',
   'user', @CurrentUser, 'table', 'TB_GetRecord', 'column', 'Id'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '�ֻ�����',
   'user', @CurrentUser, 'table', 'TB_GetRecord', 'column', 'Phone'
go

declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description', 
   '��¼ʱ��',
   'user', @CurrentUser, 'table', 'TB_GetRecord', 'column', 'CreateTime'
go

/*==============================================================*/
/* Table: tb_token                                          */
/*==============================================================*/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tb_token](
	[tokenid] [int] IDENTITY(1,1) NOT NULL,
	[token] [varchar](150) NOT NULL,
	[createdate] [datetime] NOT NULL,
	[expirdate] [datetime] NULL,
	[remark] [nvarchar](500) NULL,
 CONSTRAINT [PK_tb_token] PRIMARY KEY CLUSTERED 
(
	[tokenid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[tb_token] ADD  CONSTRAINT [DF_tb_token_createdate]  DEFAULT (getdate()) FOR [createdate]
GO
