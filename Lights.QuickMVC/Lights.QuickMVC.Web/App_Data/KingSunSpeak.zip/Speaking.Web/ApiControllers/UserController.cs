﻿using Speaking.Common;
using Speaking.Common.Model;
using Speaking.DataBase;
using Speaking.Web.ApiBLL;
using Speaking.Web.ApiModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Speaking.Web.ApiControllers
{
    public class UserController : ApiController
    {

        #region 同步用户信息
        /// <summary>
        /// 同步用户信息
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonDatas SyncUserInfo([FromBody]AM_User user)
        {
            if (!CheckToken(user.token))
            {
                return new JsonDatas { code = "0", message = "token错误" };
            }
            if (user.username != user.phone)
            {
                user.username = user.phone;
            }
            //发送请求到易助教
            string url = "http://yzj.kingsun.cn/api/user.php?action=signup&token=KINGSUN_v7k6WBLPjJQfxUM6";
            var content = new FormUrlEncodedContent(new Dictionary<string, string>() {
                    { "username", user.phone },
                    { "phone", user.phone },
                    { "user_type", user.user_type.ToString() },
                    { "password", user.password },
                    { "realname", user.realname },
                    { "sex", user.sex },
                    { "addtime", user.addtime },
                    { "identity", user.identity },
                    { "grade", user.grade },
                    { "channelCode", user.channelCode }
                });
            JsonDatas _jd = InterfacesHelper.HttpClientDoPost(url, content);
            if (_jd.code != "201")
            {
                if (!(_jd.code == "422" && _jd.message.Contains("username已存在")))
                {
                    return _jd;
                }
                else
                {
                    url = "http://yzj.kingsun.cn/api/user.php?action=updateInfo&token=KINGSUN_v7k6WBLPjJQfxUM6";
                    content = new FormUrlEncodedContent(new Dictionary<string, string>() {
                                { "username", user.username },
                                { "phone", user.phone },
                                { "user_type", user.user_type.ToString() },
                                { "password", user.password },
                                { "realname", user.realname },
                                { "sex", user.sex },
                                { "addtime", user.addtime },
                                { "identity", user.identity },
                                { "grade", user.grade },
                                { "channelCode", user.channelCode }
                            });
                    _jd = InterfacesHelper.HttpClientDoPost(url, content);
                    if (_jd.code != "200")
                    {
                        return _jd;
                    }
                }
            }

            //返回成功的信息
            UserInfo _m = PackReflectionEntity<UserInfo>.GetEntityStringToEntity(_jd.data);

          
            using (var db = new KingSunSpeakingEntities())
            {
                FZUUMS_Userservice.FZUUMS_UserServiceSoapClient client = new FZUUMS_Userservice.FZUUMS_UserServiceSoapClient();
                FZUUMS_Userservice.User _us = client.GetUserInfoByName("KS0205", user.username);
                if (_us == null)
                {
                    _us = client.GetUserInfoByTelephone("KS0205", user.username);
                    if (_us == null)
                    {
                        _us = client.InserUserSingle("KS0205", new FZUUMS_Userservice.User
                        {
                            UserName = user.username,
                            PassWord = user.password,
                            Telephone = user.phone,
                            UserType = user.user_type == 1 ? 12 : 26,
                            RegDate = DateTime.Now
                        });
                    }

                }
                if (_us != null)
                {
                    FZUUMS_Userservice.User _us2 = new FZUUMS_Userservice.User();
                    _us2.UserID = _us.UserID;
                    _us2.Telephone = user.phone;
                    _us2.TrueName = user.realname;
                    _us2.PassWord = user.password;
                    client.UpdateUserInfo2("KS0205", _us2);
                    //注册数据到方直数据池
                    // _us = client.GetUserInfoByName("KS0205", user.username);
                    TB_UserInfo ui = db.TB_UserInfo.Where(i => i.UserName == user.username).FirstOrDefault();
                    if (ui == null)
                    {
                     
                        //插入数据到数据库
                        db.TB_UserInfo.Add(new TB_UserInfo
                        {
                            UserName = user.username,
                            Resource = user.channelCode,
                            TelePhone=user.phone,
                            UserIdMod = _us.UserID,
                            CreateTime = DateTime.Now,
                            AddTime = Convert.ToDateTime(user.addtime),
                            Grade = user.grade,
                            Identity = user.identity,
                            Password = user.password,
                            RealName = user.realname,
                            Sex = user.sex,
                            Status = Convert.ToInt32(_m.status),
                            YUid = Convert.ToInt32(_m.uid),
                            UserType = user.user_type
                        });
                        db.SaveChanges();
                    }
                    else
                    {
                        ui.Resource = user.channelCode;
                        ui.Grade = user.grade;
                        ui.Password = user.password;
                        ui.RealName = user.realname;
                        ui.Sex = user.sex;
                        ui.Status = Convert.ToInt32(_m.status);
                        ui.UserType = user.user_type;
                        db.SaveChanges();
                    }
                }
                else
                {
                    _jd.code = "200";
                    _jd.message = "同步UUMS用户信息失败";
                    return _jd;//把易助教返回的信息，返回给调用者
                }
            }
            //return new Common.Model.JsonData { flag = JsonDataFlag.Succeed, data = true };
            _jd.code = "200";
            _jd.message = "同步用户信息成功";
            return _jd;//把易助教返回的信息，返回给调用者
        }
        #endregion

        #region 记录学生获取了免费课程
        /// <summary>
        /// 记录学生获取了免费课程
        /// </summary>
        /// <param name="log"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonDatas GetFreeCourse([FromBody]StuFreLog log)
        {
            JsonDatas _jd = new JsonDatas();
            using (var db = new KingSunSpeakingEntities())
            {
                var _list = db.TB_GetRecord.Where(_ => _.Phone == log.studentPhone).ToList();
                if (_list.Count > 0)
                {
                    return new JsonDatas { code = "422", message = "该手机号码已经获取过免费课程！" };
                }
                string url = "http://yzj.kingsun.cn/api/user.php?action=signStudentFreeClass&token=KINGSUN_v7k6WBLPjJQfxUM6";
                var content = new FormUrlEncodedContent(new Dictionary<string, string>() {
                    { "studentPhone", log.studentPhone }
                });
                _jd = InterfacesHelper.HttpClientDoPost(url, content);
                if (_jd.code == "200")
                {
                    db.TB_GetRecord.Add(new TB_GetRecord
                    {
                        Phone = log.studentPhone,
                        CreateTime = DateTime.Now
                    });
                    db.SaveChanges();
                }
            }
            return _jd;
        }
        #endregion

        #region 得到所有学生信息及其业务信息
        /// <summary>
        /// 得到所有学生信息及其业务信息
        /// </summary>
        /// <param name="stu"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonDatas GetStuList([FromBody]StuList stu)
        {
            if (!CheckToken(stu.token))
            {
                return new JsonDatas { code = "0", message = "token错误" };
            }
            string url = "http://yzj.kingsun.cn/api/user.php?action=queryStudentListByChannelCode&token=KINGSUN_v7k6WBLPjJQfxUM6";
            var content = new FormUrlEncodedContent(new Dictionary<string, string>() {
                    { "channelCode", stu.channelCode },
                    { "studentPhone", stu.studentPhone },
                    { "startTime", stu.startTime },
                    { "endTime", stu.endTime },
                    { "start", stu.start.ToString() },
                    { "limit", stu.limit.ToString() }
                });
            JsonDatas _jd = InterfacesHelper.HttpClientDoPost(url, content);
            return _jd;
        }
        #endregion

        #region 获取用户token(用于自动登陆)
        /// <summary>
        ///获取用户token(用于自动登陆)
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonDatas GetToken([FromBody]UserToken user)
        {
            string url = "http://yzj.kingsun.cn/api/user.php?action=getToken&token=KINGSUN_v7k6WBLPjJQfxUM6";
            var content = new FormUrlEncodedContent(new Dictionary<string, string>() {
                    { "username", user.username }
                });
            JsonDatas _jd = InterfacesHelper.HttpClientDoPost(url, content);
            return _jd;
        }
        #endregion



        private bool CheckToken(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                return false;
            }
            using (var db = new KingSunSpeakingEntities())
            {
                var tokeninfo = db.tb_token.Where(i => i.token == token).FirstOrDefault();
                if (tokeninfo != null)
                {
                    return true;
                }
                return false;
            }
        }
    }
}