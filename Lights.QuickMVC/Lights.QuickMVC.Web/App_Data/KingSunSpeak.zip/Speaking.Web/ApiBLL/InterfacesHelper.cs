﻿using Speaking.Common;
using Speaking.Web.ApiModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;

namespace Speaking.Web.ApiBLL
{
    public class InterfacesHelper
    {
        /// <summary>
        /// 发送post请求
        /// </summary>
        /// <param name="url"></param>
        /// <param name="content"></param>
        public static JsonDatas HttpClientDoPost(string url, FormUrlEncodedContent content)
        {
            JsonDatas _jd = new JsonDatas();

            var handler = new HttpClientHandler() { AutomaticDecompression = DecompressionMethods.None };

            using (var httpclient = new HttpClient(handler))
            {
                httpclient.BaseAddress = new Uri(url);

                var task = httpclient.PostAsync(url, content);
                if (task.Result.IsSuccessStatusCode)
                {
                    var rep = task.Result;//在这里会等待task返回。
                    var task2 = rep.Content.ReadAsStringAsync();//读取响应内容
                    _jd = JsonHelper.DeserializeJsonToObjectNew<JsonDatas>(task2.Result);//在这里会等待task返回。
                }
            }
            return _jd;

        }
    }
}