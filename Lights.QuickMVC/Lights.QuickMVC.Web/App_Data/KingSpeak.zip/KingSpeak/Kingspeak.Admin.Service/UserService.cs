﻿using Kingsun.Framework.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kingspeak.Admin.Service
{
    public class UserService : SqlSugarManager
    {

    }
}
